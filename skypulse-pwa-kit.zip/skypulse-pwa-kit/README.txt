# SkyPulse PWA setup

This kit is for the existing single-file SkyPulse app hosted in the repository
`yashkishorepower123-debug/SKYPULSE.`

## Files in this kit
- `manifest.json`
- `sw.js`
- `icons/icon-192.png`
- `icons/icon-512.png`

## 1. Upload files
Upload `manifest.json` and `sw.js` to the repository root (same folder as `index.html`).
Upload the entire `icons` folder so both PNGs are at the paths above.

## 2. Edit the existing index.html
Inside `<head>`, immediately after the existing theme-color meta tag, add:

```html
<link rel="manifest" href="./manifest.json">
<link rel="icon" type="image/png" sizes="192x192" href="./icons/icon-192.png">
```

Keep all existing HTML, CSS, and JavaScript.

At the bottom of `index.html`, the app currently ends with its main script tag and `</body>`.
Add the following registration code immediately before `</body>`, after the existing app script has closed:

```html
<script>
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js")
      .catch((error) => {
        console.error("SkyPulse service worker registration failed:", error);
      });
  });
}
</script>
```

Do not paste this inside the existing JavaScript script block unless you intentionally remove the extra `<script>` tags.

## 3. Publish
Commit the files on the branch used by GitHub Pages. In the repository, open Settings > Pages and confirm the publishing branch/folder is correct. Wait for deployment.

## 4. Test on Android
Open the HTTPS SkyPulse website in Chrome. Open the three-dot menu and choose Install app or Add to Home screen if offered.

The service worker caches the app shell, not live weather data. SkyPulse's weather, city search, and geolocation still need an internet connection. The external Cloudflare Worker API is intentionally not cached.
